package com.example.screenrecorder.ui.screenrecord

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Square
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.screenrecorder.ScreenRecorderApp
import com.example.screenrecorder.core.theme.AccentRecording
import com.example.screenrecorder.core.theme.SecondaryTeal
import com.example.screenrecorder.data.model.AudioCompatibility
import com.example.screenrecorder.data.model.AudioSourceMode
import com.example.screenrecorder.data.model.RecordingStatus

@Composable
fun ScreenRecordScreen(
    onStartRecording: (AudioSourceMode) -> Unit = {},
    onStopRecording: () -> Unit = {}
) {
    val context = LocalContext.current
    val app = context.applicationContext as? ScreenRecorderApp

    val status by app?.container?.recordingStatusFlow?.collectAsState()
        ?: remember { mutableStateOf(RecordingStatus.IDLE) }
    val durationSeconds by app?.container?.recordingDurationFlow?.collectAsState()
        ?: remember { mutableStateOf(0) }
    val micAmplitude by app?.container?.micAmplitudeFlow?.collectAsState()
        ?: remember { mutableStateOf(0.0f) }

    var selectedAudioSource by remember { mutableStateOf(AudioSourceMode.MIC) }
    val isRecording = status == RecordingStatus.RECORDING

    val isInternalAudioSupported = remember { AudioCompatibility.isInternalAudioSupported() }

    val animatedAmplitude by animateFloatAsState(
        targetValue = micAmplitude,
        label = "AmplitudeAnimation"
    )

    val hours = durationSeconds / 3600
    val minutes = (durationSeconds % 3600) / 60
    val seconds = durationSeconds % 60
    val timerText = String.format("%02d:%02d:%02d", hours, minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Status Card
        ElevatedCard(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.elevatedCardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(12.dp)
                            .clip(CircleShape)
                            .background(
                                when (status) {
                                    RecordingStatus.RECORDING -> AccentRecording
                                    RecordingStatus.ERROR -> MaterialTheme.colorScheme.error
                                    else -> Color(0xFF4CAF50)
                                }
                            )
                    )
                    Text(
                        text = when (status) {
                            RecordingStatus.RECORDING -> "جاري تسجيل الشاشة (${selectedAudioSource.title})"
                            RecordingStatus.ERROR -> "حدث خطأ في التسجيل"
                            else -> "جاهز للتسجيل (${selectedAudioSource.title})"
                        },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = timerText,
                    fontSize = 42.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = if (isRecording) AccentRecording else MaterialTheme.colorScheme.primary
                )
            }
        }

        // Live Mic Amplitude Meter (visible when recording with Mic)
        AnimatedVisibility(visible = isRecording && selectedAudioSource == AudioSourceMode.MIC) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Icon(
                                Icons.Default.GraphicEq,
                                contentDescription = null,
                                tint = SecondaryTeal,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = "مستوى صوت الميكروفون المباشر",
                                style = MaterialTheme.typography.bodySmall,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Text(
                            text = "${(animatedAmplitude * 100).toInt()}%",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.Bold,
                            color = SecondaryTeal
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Dynamic Audio Level Progress Bar
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(RoundedCornerShape(4.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxHeight()
                                .fillMaxWidth(animatedAmplitude.coerceIn(0.02f, 1.0f))
                                .clip(RoundedCornerShape(4.dp))
                                .background(
                                    if (animatedAmplitude > 0.85f) AccentRecording else SecondaryTeal
                                )
                        )
                    }
                }
            }
        }

        // Audio Source Selection Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Text(
                    text = "اختيار مصدر الصوت قبل التسجيل",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Option 1: None
                FilterChip(
                    modifier = Modifier.fillMaxWidth(),
                    selected = selectedAudioSource == AudioSourceMode.NONE,
                    onClick = { if (!isRecording) selectedAudioSource = AudioSourceMode.NONE },
                    enabled = !isRecording,
                    label = {
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(AudioSourceMode.NONE.title, fontWeight = FontWeight.Bold)
                            Text(
                                AudioSourceMode.NONE.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.MicOff,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 2: Mic
                FilterChip(
                    modifier = Modifier.fillMaxWidth(),
                    selected = selectedAudioSource == AudioSourceMode.MIC,
                    onClick = { if (!isRecording) selectedAudioSource = AudioSourceMode.MIC },
                    enabled = !isRecording,
                    label = {
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Text(AudioSourceMode.MIC.title, fontWeight = FontWeight.Bold)
                            Text(
                                AudioSourceMode.MIC.description,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Mic,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                )

                Spacer(modifier = Modifier.height(8.dp))

                // Option 3: Internal Audio (Conditionally enabled based on Android 10+ support)
                FilterChip(
                    modifier = Modifier.fillMaxWidth(),
                    selected = selectedAudioSource == AudioSourceMode.INTERNAL,
                    onClick = {
                        if (!isRecording && isInternalAudioSupported) {
                            selectedAudioSource = AudioSourceMode.INTERNAL
                        }
                    },
                    enabled = !isRecording && isInternalAudioSupported,
                    label = {
                        Column(modifier = Modifier.padding(vertical = 4.dp)) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Text(AudioSourceMode.INTERNAL.title, fontWeight = FontWeight.Bold)
                                if (!isInternalAudioSupported) {
                                    Text(
                                        "(غير مدعوم على جهازك)",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.error
                                    )
                                }
                            }
                            Text(
                                if (isInternalAudioSupported) AudioSourceMode.INTERNAL.description else "يتطلب إصدار Android 10 (API 29) أو أحدث",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )
                        }
                    },
                    leadingIcon = {
                        Icon(
                            Icons.Default.Headphones,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                )
            }
        }

        // Recording Action Button
        Spacer(modifier = Modifier.height(16.dp))

        Surface(
            onClick = {
                if (isRecording) {
                    onStopRecording()
                } else {
                    onStartRecording(selectedAudioSource)
                }
            },
            modifier = Modifier.size(88.dp),
            shape = CircleShape,
            color = if (isRecording) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
            shadowElevation = 8.dp
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier.fillMaxSize()
            ) {
                Icon(
                    imageVector = if (isRecording) Icons.Default.Square else Icons.Default.FiberManualRecord,
                    contentDescription = if (isRecording) "إيقاف التسجيل" else "بدء التسجيل",
                    modifier = Modifier.size(if (isRecording) 36.dp else 44.dp),
                    tint = Color.White
                )
            }
        }

        Text(
            text = if (isRecording) "اضغط لإيقاف وحفظ الفيديو والصوت في MediaStore" else "اضغط لبدء تسجيل الشاشة (${selectedAudioSource.title})",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
        )
    }
}
