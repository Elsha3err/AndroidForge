package com.example.screenrecorder.ui.audiorecord

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FiberManualRecord
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.screenrecorder.ScreenRecorderApp
import com.example.screenrecorder.core.theme.AccentRecording
import com.example.screenrecorder.core.theme.SecondaryTeal
import com.example.screenrecorder.data.model.RecordingStatus

@Composable
fun AudioRecordScreen(
    onStartRecording: () -> Unit = {},
    onPauseRecording: () -> Unit = {},
    onResumeRecording: () -> Unit = {},
    onStopRecording: () -> Unit = {}
) {
    val context = LocalContext.current
    val app = context.applicationContext as? ScreenRecorderApp

    val status by app?.container?.voiceRecordingStatusFlow?.collectAsState()
        ?: remember { mutableStateOf(RecordingStatus.IDLE) }
    val durationSeconds by app?.container?.voiceDurationFlow?.collectAsState()
        ?: remember { mutableStateOf(0) }
    val amplitude by app?.container?.voiceAmplitudeFlow?.collectAsState()
        ?: remember { mutableStateOf(0.0f) }
    val isPaused by app?.container?.voiceIsPausedFlow?.collectAsState()
        ?: remember { mutableStateOf(false) }

    val isRecording = status == RecordingStatus.RECORDING

    val animatedAmp by animateFloatAsState(
        targetValue = amplitude,
        label = "VoiceAmplitudeAnim"
    )

    val hours = durationSeconds / 3600
    val minutes = (durationSeconds % 3600) / 60
    val seconds = durationSeconds % 60
    val timerText = String.format("%02d:%02d:%02d", hours, minutes, seconds)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        // Top Info
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.padding(top = 16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(10.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isPaused -> Color(0xFFFFA000)
                                isRecording -> AccentRecording
                                else -> SecondaryTeal
                            }
                        )
                )
                Text(
                    text = when {
                        isPaused -> "التسجيل متوقف مؤقتًا"
                        isRecording -> "جاري تسجيل الصوت النقي..."
                        else -> "مسجل الصوت المستقل"
                    },
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "جودة الاستوديو (48kHz AAC Stereo • M4A)",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
            )
        }

        // Center Waveform & Timer
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            Text(
                text = timerText,
                fontSize = 54.sp,
                fontWeight = FontWeight.Light,
                color = if (isPaused) Color(0xFFFFA000) else MaterialTheme.colorScheme.onSurface
            )

            // Dynamic Audio Waveform Indicator responding to live mic amplitude
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(120.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val baseMultipliers = listOf(0.3f, 0.6f, 0.9f, 0.4f, 1.0f, 0.7f, 1.1f, 0.5f, 0.95f, 0.65f, 1.0f, 0.35f, 0.8f, 0.55f, 0.9f)
                    baseMultipliers.forEach { multiplier ->
                        val barHeight = if (isRecording && !isPaused) {
                            (14 + (animatedAmp * 80 * multiplier)).coerceIn(12f, 95f)
                        } else {
                            12f
                        }

                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .height(barHeight.dp)
                                .clip(RoundedCornerShape(3.dp))
                                .background(
                                    when {
                                        isPaused -> Color(0xFFFFA000)
                                        isRecording -> SecondaryTeal
                                        else -> Color.Gray.copy(alpha = 0.3f)
                                    }
                                )
                        )
                    }
                }
            }
        }

        // Controls
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 24.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isRecording) {
                // Pause / Resume Button
                FilledIconButton(
                    onClick = {
                        if (isPaused) {
                            onResumeRecording()
                        } else {
                            onPauseRecording()
                        }
                    },
                    modifier = Modifier.size(56.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = MaterialTheme.colorScheme.surfaceVariant
                    )
                ) {
                    Icon(
                        imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                        contentDescription = if (isPaused) "استئناف التسجيل" else "إيقاف مؤقت",
                        tint = MaterialTheme.colorScheme.onSurface
                    )
                }

                // Stop & Save Button
                Surface(
                    onClick = { onStopRecording() },
                    modifier = Modifier.size(80.dp),
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.error,
                    shadowElevation = 6.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Stop,
                            contentDescription = "إيقاف وحفظ التسجيل",
                            modifier = Modifier.size(36.dp),
                            tint = Color.White
                        )
                    }
                }
            } else {
                // Start Recording Button
                Surface(
                    onClick = { onStartRecording() },
                    modifier = Modifier.size(84.dp),
                    shape = CircleShape,
                    color = SecondaryTeal,
                    shadowElevation = 8.dp
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "بدء تسجيل الصوت",
                            modifier = Modifier.size(40.dp),
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
