package com.example.screenrecorder.core.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PermMedia
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String,
    val icon: ImageVector
) {
    data object ScreenRecord : Screen(
        route = "screen_record",
        title = "تسجيل الشاشة",
        icon = Icons.Default.Videocam
    )

    data object AudioRecord : Screen(
        route = "audio_record",
        title = "تسجيل الصوت",
        icon = Icons.Default.Mic
    )

    data object Library : Screen(
        route = "library",
        title = "المكتبة",
        icon = Icons.Default.PermMedia
    )

    data object Settings : Screen(
        route = "settings",
        title = "الإعدادات",
        icon = Icons.Default.Settings
    )
}
