package com.example.screenrecorder.core.navigation

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.example.screenrecorder.data.model.AudioSourceMode
import com.example.screenrecorder.ui.audiorecord.AudioRecordScreen
import com.example.screenrecorder.ui.library.LibraryScreen
import com.example.screenrecorder.ui.screenrecord.ScreenRecordScreen
import com.example.screenrecorder.ui.settings.SettingsScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppNavGraph(
    onStartScreenRecording: (AudioSourceMode) -> Unit,
    onStopScreenRecording: () -> Unit,
    onStartVoiceRecording: () -> Unit = {},
    onPauseVoiceRecording: () -> Unit = {},
    onResumeVoiceRecording: () -> Unit = {},
    onStopVoiceRecording: () -> Unit = {}
) {
    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val screens = listOf(
        Screen.ScreenRecord,
        Screen.AudioRecord,
        Screen.Library,
        Screen.Settings
    )

    val currentScreen = screens.find { it.route == currentRoute } ?: Screen.ScreenRecord

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = currentScreen.title,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors()
            )
        },
        bottomBar = {
            NavigationBar {
                screens.forEach { screen ->
                    val isSelected = currentRoute == screen.route
                    NavigationBarItem(
                        selected = isSelected,
                        onClick = {
                            if (!isSelected) {
                                navController.navigate(screen.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            }
                        },
                        icon = {
                            Icon(
                                imageVector = screen.icon,
                                contentDescription = screen.title
                            )
                        },
                        label = { Text(screen.title) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = Screen.ScreenRecord.route,
            modifier = Modifier.padding(innerPadding)
        ) {
            composable(Screen.ScreenRecord.route) {
                ScreenRecordScreen(
                    onStartRecording = onStartScreenRecording,
                    onStopRecording = onStopScreenRecording
                )
            }
            composable(Screen.AudioRecord.route) {
                AudioRecordScreen(
                    onStartRecording = onStartVoiceRecording,
                    onPauseRecording = onPauseVoiceRecording,
                    onResumeRecording = onResumeVoiceRecording,
                    onStopRecording = onStopVoiceRecording
                )
            }
            composable(Screen.Library.route) {
                LibraryScreen()
            }
            composable(Screen.Settings.route) {
                SettingsScreen()
            }
        }
    }
}
