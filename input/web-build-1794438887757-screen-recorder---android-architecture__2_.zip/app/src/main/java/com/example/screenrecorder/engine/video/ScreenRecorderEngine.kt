package com.example.screenrecorder.engine.video

import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.projection.MediaProjection
import android.os.ParcelFileDescriptor
import android.util.Log
import android.view.Surface
import com.example.screenrecorder.data.model.AudioConfig
import com.example.screenrecorder.data.model.AudioSourceMode
import com.example.screenrecorder.data.model.VideoConfig
import com.example.screenrecorder.engine.audio.AudioCaptureEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.FileDescriptor
import java.nio.ByteBuffer

class ScreenRecorderEngine(
    private val videoConfig: VideoConfig,
    private val audioMode: AudioSourceMode = AudioSourceMode.NONE,
    private val audioConfig: AudioConfig = AudioConfig(),
    private val onAmplitudeChanged: (Float) -> Unit = {}
) {
    private var videoEncoder: MediaCodec? = null
    private var inputSurface: Surface? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var mediaMuxer: MediaMuxer? = null

    private var audioElement: AudioCaptureEngine? = null

    private var videoTrackIndex = -1
    private var audioTrackIndex = -1

    @Volatile
    private var isMuxerStarted = false
    private val muxerLock = Any()

    private var drainJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private var startTimeNs: Long = 0L
    private var lastVideoPtsUs: Long = -1L

    @Volatile
    private var isRecording = false

    fun start(
        mediaProjection: MediaProjection,
        destinationPfd: ParcelFileDescriptor,
        onError: (Throwable) -> Unit
    ) {
        try {
            initVideoEncoder()
            initMuxer(destinationPfd.fileDescriptor)

            if (audioMode != AudioSourceMode.NONE) {
                audioElement = AudioCaptureEngine(
                    mode = audioMode,
                    config = audioConfig,
                    onTrackFormatReady = { audioFormat ->
                        synchronized(muxerLock) {
                            val muxer = mediaMuxer ?: return@synchronized
                            if (audioTrackIndex < 0 && !isMuxerStarted) {
                                audioTrackIndex = muxer.addTrack(audioFormat)
                                checkAndStartMuxer()
                            }
                        }
                    },
                    onSampleReady = { buffer, bufferInfo ->
                        synchronized(muxerLock) {
                            if (isMuxerStarted && audioTrackIndex >= 0) {
                                mediaMuxer?.writeSampleData(audioTrackIndex, buffer, bufferInfo)
                            }
                        }
                    },
                    onAmplitudeChanged = onAmplitudeChanged,
                    onError = onError
                )
            }

            virtualDisplay = mediaProjection.createVirtualDisplay(
                "ScreenRecorderDisplay",
                videoConfig.width,
                videoConfig.height,
                videoConfig.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                inputSurface,
                null,
                null
            )

            videoEncoder?.start()
            audioElement?.start(mediaProjection)

            isRecording = true
            startTimeNs = System.nanoTime()

            drainJob = scope.launch {
                drainVideoEncoder(onError)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start ScreenRecorderEngine", e)
            release()
            onError(e)
        }
    }

    private fun initVideoEncoder() {
        val format = MediaFormat.createVideoFormat(
            MediaFormat.MIMETYPE_VIDEO_AVC,
            videoConfig.width,
            videoConfig.height
        ).apply {
            setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
            setInteger(MediaFormat.KEY_BIT_RATE, videoConfig.bitRate)
            setInteger(MediaFormat.KEY_FRAME_RATE, videoConfig.frameRate)
            setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, videoConfig.iFrameInterval)
        }

        videoEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            inputSurface = createInputSurface()
        }
    }

    private fun initMuxer(fileDescriptor: FileDescriptor) {
        mediaMuxer = MediaMuxer(fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        videoTrackIndex = -1
        audioTrackIndex = -1
        isMuxerStarted = false
    }

    private fun checkAndStartMuxer() {
        val needsAudio = audioMode != AudioSourceMode.NONE
        val isVideoReady = videoTrackIndex >= 0
        val isAudioReady = if (needsAudio) audioTrackIndex >= 0 else true

        if (isVideoReady && isAudioReady && !isMuxerStarted) {
            mediaMuxer?.start()
            isMuxerStarted = true
            Log.d(TAG, "MediaMuxer started successfully (Video track: $videoTrackIndex, Audio track: $audioTrackIndex)")
        }
    }

    private fun drainVideoEncoder(onError: (Throwable) -> Unit) {
        val encoder = videoEncoder ?: return
        val bufferInfo = MediaCodec.BufferInfo()

        try {
            while (scope.isActive && isRecording) {
                val outputBufferIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)

                when (outputBufferIndex) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> continue
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        synchronized(muxerLock) {
                            if (!isMuxerStarted && videoTrackIndex < 0) {
                                val muxer = mediaMuxer ?: return@synchronized
                                videoTrackIndex = muxer.addTrack(encoder.outputFormat)
                                checkAndStartMuxer()
                            }
                        }
                    }
                    else -> {
                        if (outputBufferIndex < 0) continue

                        val outputBuffer: ByteBuffer = encoder.getOutputBuffer(outputBufferIndex)
                            ?: continue

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size != 0) {
                            synchronized(muxerLock) {
                                if (isMuxerStarted && videoTrackIndex >= 0) {
                                    outputBuffer.position(bufferInfo.offset)
                                    outputBuffer.limit(bufferInfo.offset + bufferInfo.size)

                                    val calculatedPtsUs = (bufferInfo.presentationTimeUs - (startTimeNs / 1000L)).coerceAtLeast(0L)
                                    val finalPtsUs = if (lastVideoPtsUs >= calculatedPtsUs) lastVideoPtsUs + 1000L else calculatedPtsUs
                                    lastVideoPtsUs = finalPtsUs
                                    bufferInfo.presentationTimeUs = finalPtsUs

                                    mediaMuxer?.writeSampleData(videoTrackIndex, outputBuffer, bufferInfo)
                                }
                            }
                        }

                        encoder.releaseOutputBuffer(outputBufferIndex, false)

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in drainVideoEncoder", e)
            onError(e)
        }
    }

    fun stop() {
        if (!isRecording) return
        isRecording = false

        try {
            audioElement?.stop()
            videoEncoder?.signalEndOfInputStream()
            drainJob?.cancel()
        } catch (e: Exception) {
            Log.w(TAG, "Exception during stop", e)
        } finally {
            release()
        }
    }

    fun release() {
        isRecording = false
        try {
            virtualDisplay?.release()
            virtualDisplay = null

            inputSurface?.release()
            inputSurface = null

            videoEncoder?.run {
                try { stop() } catch (ignored: Exception) {}
                release()
            }
            videoEncoder = null

            audioElement?.release()
            audioElement = null

            synchronized(muxerLock) {
                mediaMuxer?.run {
                    if (isMuxerStarted) {
                        try { stop() } catch (ignored: Exception) {}
                    }
                    release()
                }
                mediaMuxer = null
                isMuxerStarted = false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error during engine release", e)
        }
    }

    companion object {
        private const val TAG = "ScreenRecorderEngine"
        private const val TIMEOUT_US = 10_000L
    }
}
