package com.example.screenrecorder.data.model

data class VideoConfig(
    val width: Int = 1080,
    val height: Int = 1920,
    val densityDpi: Int = 400,
    val frameRate: Int = 60,
    val bitRate: Int = 8_000_000,
    val iFrameInterval: Int = 1
)

enum class RecordingStatus {
    IDLE,
    RECORDING,
    PAUSED,
    ERROR
}
