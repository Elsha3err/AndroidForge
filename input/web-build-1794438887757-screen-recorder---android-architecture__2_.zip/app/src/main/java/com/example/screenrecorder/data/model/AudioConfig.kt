package com.example.screenrecorder.data.model

import android.os.Build

enum class AudioSourceMode(val title: String, val description: String) {
    NONE("بدون صوت", "تسجيل شاشة صامت بدون أي مدخلات صوتية"),
    MIC("صوت الميكروفون", "تسجيل تعليقك الصوتي ومحيط الجهاز عبر الميكروفون"),
    INTERNAL("الصوت الداخلي فقط", "تسجيل صوت التطبيقات والألعاب بدقة رقمية (Android 10+)")
}

data class AudioConfig(
    val sampleRate: Int = 44100,
    val channelCount: Int = 2,
    val bitRate: Int = 128_000
)

object AudioCompatibility {
    fun isInternalAudioSupported(): Boolean {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q
    }
}
