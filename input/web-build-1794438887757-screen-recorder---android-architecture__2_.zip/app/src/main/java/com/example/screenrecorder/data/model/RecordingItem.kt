package com.example.screenrecorder.data.model

import android.net.Uri

data class RecordingItem(
    val id: Long,
    val uri: Uri,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val dateAddedSec: Long,
    val isVideo: Boolean
)
