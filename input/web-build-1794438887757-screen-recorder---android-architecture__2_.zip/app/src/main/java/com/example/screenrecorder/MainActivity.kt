package com.example.screenrecorder

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.example.screenrecorder.core.navigation.AppNavGraph
import com.example.screenrecorder.core.theme.ScreenRecorderTheme
import com.example.screenrecorder.data.model.AudioCompatibility
import com.example.screenrecorder.data.model.AudioSourceMode
import com.example.screenrecorder.service.AudioRecordingService
import com.example.screenrecorder.service.ScreenRecordingService

class MainActivity : ComponentActivity() {

    private var pendingAudioMode: AudioSourceMode = AudioSourceMode.NONE
    private var pendingActionIsVoiceRecorder: Boolean = false

    private val screenCaptureLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val serviceIntent = Intent(this, ScreenRecordingService::class.java).apply {
                action = ScreenRecordingService.ACTION_START
                putExtra(ScreenRecordingService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenRecordingService.EXTRA_RESULT_DATA, result.data)
                putExtra(ScreenRecordingService.EXTRA_AUDIO_SOURCE, pendingAudioMode.name)
            }
            ContextCompat.startForegroundService(this, serviceIntent)
        } else {
            Toast.makeText(this, "تم إلغاء إذن تسجيل الشاشة", Toast.LENGTH_SHORT).show()
        }
    }

    private val requestAudioPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            if (pendingActionIsVoiceRecorder) {
                startVoiceRecordingService()
            } else {
                launchScreenCapture()
            }
        } else {
            Toast.makeText(this, "يلزم منح صلاحية الميكروفون لتسجيل الصوت", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            ScreenRecorderTheme {
                AppNavGraph(
                    onStartScreenRecording = { audioMode -> handleStartScreenRecording(audioMode) },
                    onStopScreenRecording = { stopScreenRecording() },
                    onStartVoiceRecording = { handleStartVoiceRecording() },
                    onPauseVoiceRecording = { pauseVoiceRecording() },
                    onResumeVoiceRecording = { resumeVoiceRecording() },
                    onStopVoiceRecording = { stopVoiceRecording() }
                )
            }
        }
    }

    private fun handleStartScreenRecording(audioMode: AudioSourceMode) {
        pendingAudioMode = audioMode
        pendingActionIsVoiceRecorder = false

        when (audioMode) {
            AudioSourceMode.NONE -> {
                launchScreenCapture()
            }
            AudioSourceMode.MIC -> {
                val hasPermission = ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.RECORD_AUDIO
                ) == PackageManager.PERMISSION_GRANTED

                if (hasPermission) {
                    launchScreenCapture()
                } else {
                    requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                }
            }
            AudioSourceMode.INTERNAL -> {
                if (!AudioCompatibility.isInternalAudioSupported()) {
                    Toast.makeText(this, "تسجيل الصوت الداخلي مدعوم فقط على Android 10 فما فوق", Toast.LENGTH_LONG).show()
                    return
                }
                launchScreenCapture()
            }
        }
    }

    private fun handleStartVoiceRecording() {
        pendingActionIsVoiceRecorder = true
        val hasPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasPermission) {
            startVoiceRecordingService()
        } else {
            requestAudioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    private fun startVoiceRecordingService() {
        val intent = Intent(this, AudioRecordingService::class.java).apply {
            action = AudioRecordingService.ACTION_START
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun pauseVoiceRecording() {
        val intent = Intent(this, AudioRecordingService::class.java).apply {
            action = AudioRecordingService.ACTION_PAUSE
        }
        startService(intent)
    }

    private fun resumeVoiceRecording() {
        val intent = Intent(this, AudioRecordingService::class.java).apply {
            action = AudioRecordingService.ACTION_RESUME
        }
        startService(intent)
    }

    private fun stopVoiceRecording() {
        val intent = Intent(this, AudioRecordingService::class.java).apply {
            action = AudioRecordingService.ACTION_STOP
        }
        startService(intent)
    }

    private fun launchScreenCapture() {
        val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        screenCaptureLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun stopScreenRecording() {
        val stopIntent = Intent(this, ScreenRecordingService::class.java).apply {
            action = ScreenRecordingService.ACTION_STOP
        }
        startService(stopIntent)
    }
}
