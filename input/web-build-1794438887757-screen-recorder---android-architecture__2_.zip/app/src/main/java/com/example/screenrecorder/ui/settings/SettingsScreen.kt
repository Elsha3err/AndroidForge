package com.example.screenrecorder.ui.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.screenrecorder.ScreenRecorderApp
import com.example.screenrecorder.core.theme.SecondaryTeal

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as? ScreenRecorderApp
    val repository = app?.container?.settingsRepository

    val selectedResolution by repository?.resolutionLabelFlow?.collectAsState()
        ?: remember { mutableStateOf("1080p") }
    val selectedFps by repository?.fpsLabelFlow?.collectAsState()
        ?: remember { mutableStateOf(60) }
    val selectedBitrate by repository?.bitrateLabelFlow?.collectAsState()
        ?: remember { mutableStateOf("8 Mbps") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Video Quality Section
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.Videocam, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
            Text(
                text = "جودة تسجيل الفيديو",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Resolution Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "دقة الفيديو (Resolution)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("1080p", "720p", "480p").forEach { res ->
                            FilterChip(
                                selected = selectedResolution == res,
                                onClick = { repository?.setResolution(res) },
                                label = {
                                    Text(
                                        when (res) {
                                            "1080p" -> "1080p (Full HD)"
                                            "720p" -> "720p (HD)"
                                            else -> "480p (SD)"
                                        }
                                    )
                                }
                            )
                        }
                    }
                }

                // Frame Rate Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "معدل الإطارات (Frame Rate)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf(60, 30, 24).forEach { fpsVal ->
                            FilterChip(
                                selected = selectedFps == fpsVal,
                                onClick = { repository?.setFrameRate(fpsVal) },
                                label = { Text("$fpsVal FPS") }
                            )
                        }
                    }
                }

                // Bitrate Selector
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = "معدل نقل البيانات (Bitrate)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("12 Mbps", "8 Mbps", "4 Mbps").forEach { br ->
                            FilterChip(
                                selected = selectedBitrate == br,
                                onClick = { repository?.setBitrate(br) },
                                label = { Text(br) }
                            )
                        }
                    }
                }
            }
        }

        // Audio Quality Section
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(Icons.Default.GraphicEq, contentDescription = null, tint = SecondaryTeal)
            Text(
                text = "جودة الصوت والترميز",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = SecondaryTeal
            )
        }

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(text = "معدل أخذ العينات (Sample Rate)", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = true,
                        onClick = { repository?.setAudioSampleRate(48000) },
                        label = { Text("48 kHz (Studio Audio)") }
                    )
                    FilterChip(
                        selected = false,
                        onClick = { repository?.setAudioSampleRate(44100) },
                        label = { Text("44.1 kHz (CD Audio)") }
                    )
                }

                Text(
                    text = "الترميز المعتمد: AAC-LC Stereo • 128 kbps",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                )
            }
        }

        // System Compatibility Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(18.dp),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surface
            )
        ) {
            Row(
                modifier = Modifier.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(Icons.Default.Info, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Column {
                    Text("معلومات النظام والتخزين", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "يتم حفظ الفيديوهات في Movies/ScreenRecordings والأصوات في Recordings/VoiceRecordings دون الحاجة لأي صلاحيات تخزين زائدة بفضل معايير Scoped Storage.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
            }
        }
    }
}
