package com.example.screenrecorder

import android.content.Context
import com.example.screenrecorder.data.model.RecordingStatus
import com.example.screenrecorder.data.repository.MediaRepository
import com.example.screenrecorder.data.repository.MediaRepositoryImpl
import com.example.screenrecorder.data.repository.SettingsRepository
import com.example.screenrecorder.data.repository.SettingsRepositoryImpl
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface AppContainer {
    val applicationContext: Context
    val mediaRepository: MediaRepository
    val settingsRepository: SettingsRepository

    // Screen Recording State
    val recordingStatusFlow: StateFlow<RecordingStatus>
    val recordingDurationFlow: StateFlow<Int>
    val micAmplitudeFlow: StateFlow<Float>

    fun updateRecordingStatus(status: RecordingStatus)
    fun updateDuration(seconds: Int)
    fun updateMicAmplitude(amp: Float)

    // Voice Recorder State
    val voiceRecordingStatusFlow: StateFlow<RecordingStatus>
    val voiceDurationFlow: StateFlow<Int>
    val voiceAmplitudeFlow: StateFlow<Float>
    val voiceIsPausedFlow: StateFlow<Boolean>

    fun updateVoiceStatus(status: RecordingStatus)
    fun updateVoiceDuration(seconds: Int)
    fun updateVoiceAmplitude(amp: Float)
    fun updateVoicePaused(isPaused: Boolean)
}

class DefaultAppContainer(
    override val applicationContext: Context
) : AppContainer {

    override val mediaRepository: MediaRepository by lazy {
        MediaRepositoryImpl(applicationContext)
    }

    override val settingsRepository: SettingsRepository by lazy {
        SettingsRepositoryImpl(applicationContext)
    }

    // Screen Recording State
    private val _recordingStatusFlow = MutableStateFlow(RecordingStatus.IDLE)
    override val recordingStatusFlow: StateFlow<RecordingStatus> = _recordingStatusFlow.asStateFlow()

    private val _recordingDurationFlow = MutableStateFlow(0)
    override val recordingDurationFlow: StateFlow<Int> = _recordingDurationFlow.asStateFlow()

    private val _micAmplitudeFlow = MutableStateFlow(0.0f)
    override val micAmplitudeFlow: StateFlow<Float> = _micAmplitudeFlow.asStateFlow()

    override fun updateRecordingStatus(status: RecordingStatus) {
        _recordingStatusFlow.value = status
    }

    override fun updateDuration(seconds: Int) {
        _recordingDurationFlow.value = seconds
    }

    override fun updateMicAmplitude(amp: Float) {
        _micAmplitudeFlow.value = amp
    }

    // Voice Recorder State
    private val _voiceRecordingStatusFlow = MutableStateFlow(RecordingStatus.IDLE)
    override val voiceRecordingStatusFlow: StateFlow<RecordingStatus> = _voiceRecordingStatusFlow.asStateFlow()

    private val _voiceDurationFlow = MutableStateFlow(0)
    override val voiceDurationFlow: StateFlow<Int> = _voiceDurationFlow.asStateFlow()

    private val _voiceAmplitudeFlow = MutableStateFlow(0.0f)
    override val voiceAmplitudeFlow: StateFlow<Float> = _voiceAmplitudeFlow.asStateFlow()

    private val _voiceIsPausedFlow = MutableStateFlow(false)
    override val voiceIsPausedFlow: StateFlow<Boolean> = _voiceIsPausedFlow.asStateFlow()

    override fun updateVoiceStatus(status: RecordingStatus) {
        _voiceRecordingStatusFlow.value = status
    }

    override fun updateVoiceDuration(seconds: Int) {
        _voiceDurationFlow.value = seconds
    }

    override fun updateVoiceAmplitude(amp: Float) {
        _voiceAmplitudeFlow.value = amp
    }

    override fun updateVoicePaused(isPaused: Boolean) {
        _voiceIsPausedFlow.value = isPaused
    }
}
