package com.example.screenrecorder.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.screenrecorder.MainActivity
import com.example.screenrecorder.ScreenRecorderApp
import com.example.screenrecorder.data.model.AudioConfig
import com.example.screenrecorder.data.model.AudioSourceMode
import com.example.screenrecorder.data.model.RecordingStatus
import com.example.screenrecorder.data.model.VideoConfig
import com.example.screenrecorder.engine.video.ScreenRecorderEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class ScreenRecordingService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var engine: ScreenRecorderEngine? = null
    private var outputUri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null

    private var timerJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private var elapsedSeconds = 0

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            Log.d(TAG, "MediaProjection stopped by system/user")
            stopRecording()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                val audioModeName = intent.getStringExtra(EXTRA_AUDIO_SOURCE) ?: AudioSourceMode.NONE.name
                val audioMode = try {
                    AudioSourceMode.valueOf(audioModeName)
                } catch (e: Exception) {
                    AudioSourceMode.NONE
                }

                if (resultCode != 0 && resultData != null) {
                    startRecording(resultCode, resultData, audioMode)
                } else {
                    Log.e(TAG, "Invalid result data or code for ScreenRecordingService")
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                stopRecording()
            }
        }
        return START_NOT_STICKY
    }

    private fun startRecording(resultCode: Int, resultData: Intent, audioMode: AudioSourceMode) {
        val app = application as? ScreenRecorderApp
        val container = app?.container

        try {
            // 1. Start Foreground immediately with notification
            val notification = buildNotification(0, audioMode)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val serviceType = if (audioMode == AudioSourceMode.MIC) {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                } else {
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                }
                startForeground(NOTIFICATION_ID, notification, serviceType)
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            // 2. Obtain MediaProjection and register callback
            val projectionManager = getSystemService(MediaProjectionManager::class.java)
            mediaProjection = projectionManager.getMediaProjection(resultCode, resultData)
            mediaProjection?.registerCallback(projectionCallback, null)

            // 3. Create MediaStore destination
            val (uri, fileDescriptor) = createVideoMediaStoreEntry()
            outputUri = uri
            pfd = fileDescriptor

            // 4. Initialize and start engine with user configured quality settings
            val videoConfig = container?.settingsRepository?.videoConfigFlow?.value ?: VideoConfig()
            val audioConfig = container?.settingsRepository?.audioConfigFlow?.value ?: AudioConfig()

            engine = ScreenRecorderEngine(
                videoConfig = videoConfig,
                audioMode = audioMode,
                audioConfig = audioConfig,
                onAmplitudeChanged = { amp ->
                    container?.updateMicAmplitude(amp)
                }
            )

            engine?.start(
                mediaProjection = mediaProjection!!,
                destinationPfd = fileDescriptor,
                onError = { throwable ->
                    Log.e(TAG, "Engine error during recording", throwable)
                    container?.updateRecordingStatus(RecordingStatus.ERROR)
                    stopRecording(isError = true)
                }
            )

            // 5. Update state and start timer
            container?.updateRecordingStatus(RecordingStatus.RECORDING)
            startTimer()

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start recording service", e)
            container?.updateRecordingStatus(RecordingStatus.ERROR)
            stopRecording(isError = true)
        }
    }

    private fun createVideoMediaStoreEntry(): Pair<Uri, ParcelFileDescriptor> {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "REC_Screen_$timeStamp.mp4"

        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/ScreenRecordings")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
        }

        val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Failed to insert MediaStore record")

        val fileDescriptor = contentResolver.openFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("Failed to open ParcelFileDescriptor for URI: $uri")

        return Pair(uri, fileDescriptor)
    }

    private fun startTimer() {
        elapsedSeconds = 0
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                delay(1000L)
                elapsedSeconds++
                val app = application as? ScreenRecorderApp
                app?.container?.updateDuration(elapsedSeconds)
            }
        }
    }

    private fun stopRecording(isError: Boolean = false) {
        val app = application as? ScreenRecorderApp
        val container = app?.container

        timerJob?.cancel()
        timerJob = null

        try {
            engine?.stop()
            engine = null

            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
            mediaProjection = null

            pfd?.close()
            pfd = null

            outputUri?.let { uri ->
                if (isError) {
                    contentResolver.delete(uri, null, null)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Video.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, values, null, null)
                }
            }

            container?.updateRecordingStatus(if (isError) RecordingStatus.ERROR else RecordingStatus.IDLE)
            container?.updateMicAmplitude(0.0f)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping recording", e)
        } finally {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun buildNotification(seconds: Int, audioMode: AudioSourceMode): Notification {
        val stopIntent = Intent(this, ScreenRecordingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val audioSubtitle = when (audioMode) {
            AudioSourceMode.NONE -> "بدون صوت"
            AudioSourceMode.MIC -> "مع صوت الميكروفون"
            AudioSourceMode.INTERNAL -> "مع الصوت الداخلي"
        }

        return NotificationCompat.Builder(this, ScreenRecorderApp.CHANNEL_SCREEN_RECORD)
            .setContentTitle("تسجيل الشاشة نشط ($audioSubtitle)")
            .setContentText("جاري تسجيل الشاشة وحفظ الفيديو...")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .setContentIntent(contentPendingIntent)
            .addAction(android.R.drawable.ic_media_pause, "إيقاف وحفظ", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "ScreenRecordingService"
        private const val NOTIFICATION_ID = 1001

        const val ACTION_START = "com.example.screenrecorder.action.START"
        const val ACTION_STOP = "com.example.screenrecorder.action.STOP"

        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_RESULT_DATA = "extra_result_data"
        const val EXTRA_AUDIO_SOURCE = "extra_audio_source"
    }
}
