package com.example.screenrecorder.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.screenrecorder.data.model.AudioConfig
import com.example.screenrecorder.data.model.VideoConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

interface SettingsRepository {
    val videoConfigFlow: StateFlow<VideoConfig>
    val audioConfigFlow: StateFlow<AudioConfig>
    val resolutionLabelFlow: StateFlow<String>
    val fpsLabelFlow: StateFlow<Int>
    val bitrateLabelFlow: StateFlow<String>

    fun setResolution(resolution: String)
    fun setFrameRate(fps: Int)
    fun setBitrate(bitrate: String)
    fun setAudioSampleRate(sampleRate: Int)
}

class SettingsRepositoryImpl(
    context: Context
) : SettingsRepository {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    private val _resolutionLabelFlow = MutableStateFlow(prefs.getString(KEY_RESOLUTION, "1080p") ?: "1080p")
    override val resolutionLabelFlow: StateFlow<String> = _resolutionLabelFlow.asStateFlow()

    private val _fpsLabelFlow = MutableStateFlow(prefs.getInt(KEY_FPS, 60))
    override val fpsLabelFlow: StateFlow<Int> = _fpsLabelFlow.asStateFlow()

    private val _bitrateLabelFlow = MutableStateFlow(prefs.getString(KEY_BITRATE, "8 Mbps") ?: "8 Mbps")
    override val bitrateLabelFlow: StateFlow<String> = _bitrateLabelFlow.asStateFlow()

    private val _videoConfigFlow = MutableStateFlow(buildVideoConfig())
    override val videoConfigFlow: StateFlow<VideoConfig> = _videoConfigFlow.asStateFlow()

    private val _audioConfigFlow = MutableStateFlow(buildAudioConfig())
    override val audioConfigFlow: StateFlow<AudioConfig> = _audioConfigFlow.asStateFlow()

    override fun setResolution(resolution: String) {
        prefs.edit().putString(KEY_RESOLUTION, resolution).apply()
        _resolutionLabelFlow.value = resolution
        _videoConfigFlow.value = buildVideoConfig()
    }

    override fun setFrameRate(fps: Int) {
        prefs.edit().putInt(KEY_FPS, fps).apply()
        _fpsLabelFlow.value = fps
        _videoConfigFlow.value = buildVideoConfig()
    }

    override fun setBitrate(bitrate: String) {
        prefs.edit().putString(KEY_BITRATE, bitrate).apply()
        _bitrateLabelFlow.value = bitrate
        _videoConfigFlow.value = buildVideoConfig()
    }

    override fun setAudioSampleRate(sampleRate: Int) {
        prefs.edit().putInt(KEY_SAMPLE_RATE, sampleRate).apply()
        _audioConfigFlow.value = buildAudioConfig()
    }

    private fun buildVideoConfig(): VideoConfig {
        val (w, h, dpi) = when (_resolutionLabelFlow.value) {
            "720p" -> Triple(720, 1280, 320)
            "480p" -> Triple(480, 854, 240)
            else -> Triple(1080, 1920, 400)
        }

        val bps = when (_bitrateLabelFlow.value) {
            "12 Mbps" -> 12_000_000
            "4 Mbps" -> 4_000_000
            else -> 8_000_000
        }

        return VideoConfig(
            width = w,
            height = h,
            densityDpi = dpi,
            frameRate = _fpsLabelFlow.value,
            bitRate = bps
        )
    }

    private fun buildAudioConfig(): AudioConfig {
        val sampleRate = prefs.getInt(KEY_SAMPLE_RATE, 44100)
        return AudioConfig(
            sampleRate = sampleRate,
            channelCount = 2,
            bitRate = 128_000
        )
    }

    companion object {
        private const val PREFS_NAME = "screen_recorder_prefs"
        private const val KEY_RESOLUTION = "pref_resolution"
        private const val KEY_FPS = "pref_fps"
        private const val KEY_BITRATE = "pref_bitrate"
        private const val KEY_SAMPLE_RATE = "pref_sample_rate"
    }
}
