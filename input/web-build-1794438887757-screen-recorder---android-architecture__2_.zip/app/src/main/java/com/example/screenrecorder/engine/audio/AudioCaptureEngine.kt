package com.example.screenrecorder.engine.audio

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.os.Build
import android.util.Log
import com.example.screenrecorder.data.model.AudioConfig
import com.example.screenrecorder.data.model.AudioSourceMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.abs

class AudioCaptureEngine(
    private val mode: AudioSourceMode,
    private val config: AudioConfig,
    private val onTrackFormatReady: (MediaFormat) -> Unit,
    private val onSampleReady: (ByteBuffer, MediaCodec.BufferInfo) -> Unit,
    private val onAmplitudeChanged: (Float) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    private var audioRecord: AudioRecord? = null
    private var audioEncoder: MediaCodec? = null

    private var recordJob: Job? = null
    private var drainJob: Job? = null
    private val scope = CoroutineScope(Dispatchers.IO)

    private var startTimeNs: Long = 0L
    private var lastPtsUs: Long = -1L

    @Volatile
    private var isCapturing = false

    @SuppressLint("MissingPermission")
    fun start(mediaProjection: MediaProjection?) {
        if (mode == AudioSourceMode.NONE) return

        try {
            initEncoder()
            initAudioRecord(mediaProjection)

            audioRecord?.startRecording()
            audioEncoder?.start()
            isCapturing = true
            startTimeNs = System.nanoTime()

            recordJob = scope.launch {
                readPcmLoop()
            }

            drainJob = scope.launch {
                drainEncoderLoop()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start AudioCaptureEngine", e)
            release()
            onError(e)
        }
    }

    private fun initEncoder() {
        val format = MediaFormat.createAudioFormat(
            MediaFormat.MIMETYPE_AUDIO_AAC,
            config.sampleRate,
            config.channelCount
        ).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, config.bitRate)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }

        audioEncoder = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC).apply {
            configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        }
    }

    @SuppressLint("MissingPermission")
    private fun initAudioRecord(mediaProjection: MediaProjection?) {
        val channelMask = if (config.channelCount == 1) {
            AudioFormat.CHANNEL_IN_MONO
        } else {
            AudioFormat.CHANNEL_IN_STEREO
        }
        val minBufferSize = AudioRecord.getMinBufferSize(
            config.sampleRate,
            channelMask,
            AudioFormat.ENCODING_PCM_16BIT
        ).coerceAtLeast(8192)

        audioRecord = when (mode) {
            AudioSourceMode.MIC -> {
                AudioRecord(
                    MediaRecorder.AudioSource.MIC,
                    config.sampleRate,
                    channelMask,
                    AudioFormat.ENCODING_PCM_16BIT,
                    minBufferSize * 2
                )
            }
            AudioSourceMode.INTERNAL -> {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && mediaProjection != null) {
                    val playbackConfig = AudioPlaybackCaptureConfiguration.Builder(mediaProjection)
                        .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                        .addMatchingUsage(AudioAttributes.USAGE_GAME)
                        .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                        .build()

                    val audioFormat = AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(config.sampleRate)
                        .setChannelMask(channelMask)
                        .build()

                    AudioRecord.Builder()
                        .setAudioPlaybackCaptureConfig(playbackConfig)
                        .setAudioFormat(audioFormat)
                        .setBufferSizeInBytes(minBufferSize * 2)
                        .build()
                } else {
                    throw IllegalStateException("Internal audio requires Android 10+ and an active MediaProjection")
                }
            }
            AudioSourceMode.NONE -> null
        }

        if (audioRecord?.state != AudioRecord.STATE_INITIALIZED) {
            throw IllegalStateException("AudioRecord failed to initialize for mode: $mode")
        }
    }

    private fun readPcmLoop() {
        val record = audioRecord ?: return
        val encoder = audioEncoder ?: return
        val pcmBuffer = ByteArray(4096)

        try {
            while (scope.isActive && isCapturing) {
                val bytesRead = record.read(pcmBuffer, 0, pcmBuffer.size)
                if (bytesRead <= 0) continue

                // Calculate peak amplitude for UI level meter
                calculatePeakAmplitude(pcmBuffer, bytesRead)

                // Feed PCM buffer to MediaCodec input buffer
                val inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US)
                if (inputIndex >= 0) {
                    val inputBuffer = encoder.getInputBuffer(inputIndex) ?: continue
                    inputBuffer.clear()
                    inputBuffer.put(pcmBuffer, 0, bytesRead)

                    val ptsUs = ((System.nanoTime() - startTimeNs) / 1000L).coerceAtLeast(0L)
                    encoder.queueInputBuffer(inputIndex, 0, bytesRead, ptsUs, 0)
                }
            }

            // Signal End of Stream to encoder
            val inputIndex = encoder.dequeueInputBuffer(TIMEOUT_US)
            if (inputIndex >= 0) {
                encoder.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in readPcmLoop", e)
            onError(e)
        }
    }

    private fun drainEncoderLoop() {
        val encoder = audioEncoder ?: return
        val bufferInfo = MediaCodec.BufferInfo()

        try {
            while (scope.isActive && isCapturing) {
                val outputIndex = encoder.dequeueOutputBuffer(bufferInfo, TIMEOUT_US)
                when (outputIndex) {
                    MediaCodec.INFO_TRY_AGAIN_LATER -> continue
                    MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        onTrackFormatReady(encoder.outputFormat)
                    }
                    else -> {
                        if (outputIndex < 0) continue
                        val outputBuffer = encoder.getOutputBuffer(outputIndex) ?: continue

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                            bufferInfo.size = 0
                        }

                        if (bufferInfo.size != 0) {
                            outputBuffer.position(bufferInfo.offset)
                            outputBuffer.limit(bufferInfo.offset + bufferInfo.size)

                            val calculatedPtsUs = bufferInfo.presentationTimeUs.coerceAtLeast(0L)
                            val finalPtsUs = if (lastPtsUs >= calculatedPtsUs) lastPtsUs + 1000L else calculatedPtsUs
                            lastPtsUs = finalPtsUs
                            bufferInfo.presentationTimeUs = finalPtsUs

                            onSampleReady(outputBuffer, bufferInfo)
                        }

                        encoder.releaseOutputBuffer(outputIndex, false)

                        if ((bufferInfo.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) {
                            break
                        }
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in drainEncoderLoop", e)
            onError(e)
        }
    }

    private fun calculatePeakAmplitude(buffer: ByteArray, length: Int) {
        val byteBuffer = ByteBuffer.wrap(buffer, 0, length).order(ByteOrder.LITTLE_ENDIAN)
        var maxSample = 0

        while (byteBuffer.remaining() >= 2) {
            val sample = byteBuffer.short.toInt()
            val absSample = abs(sample)
            if (absSample > maxSample) {
                maxSample = absSample
            }
        }

        val normalized = (maxSample / 32768f).coerceIn(0.0f, 1.0f)
        onAmplitudeChanged(normalized)
    }

    fun stop() {
        isCapturing = false
        try {
            audioRecord?.stop()
        } catch (ignored: Exception) {}
        recordJob?.cancel()
        drainJob?.cancel()
        release()
    }

    fun release() {
        isCapturing = false
        onAmplitudeChanged(0.0f)

        try {
            audioRecord?.release()
        } catch (ignored: Exception) {}
        audioRecord = null

        try {
            audioEncoder?.run {
                try { stop() } catch (ignored: Exception) {}
                release()
            }
        } catch (ignored: Exception) {}
        audioEncoder = null
    }

    companion object {
        private const val TAG = "AudioCaptureEngine"
        private const val TIMEOUT_US = 10_000L
    }
}
