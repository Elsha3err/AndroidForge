package com.example.screenrecorder.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.IBinder
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.screenrecorder.MainActivity
import com.example.screenrecorder.ScreenRecorderApp
import com.example.screenrecorder.data.model.RecordingStatus
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class AudioRecordingService : Service() {

    private var mediaRecorder: MediaRecorder? = null
    private var outputUri: Uri? = null
    private var pfd: ParcelFileDescriptor? = null

    private var timerJob: Job? = null
    private var amplitudeJob: Job? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main)

    private var elapsedSeconds = 0
    private var isPaused = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startRecording()
            ACTION_PAUSE -> pauseRecording()
            ACTION_RESUME -> resumeRecording()
            ACTION_STOP -> stopRecording()
        }
        return START_NOT_STICKY
    }

    private fun startRecording() {
        val app = application as? ScreenRecorderApp
        val container = app?.container

        try {
            // 1. Start foreground service
            val notification = buildNotification(0, false)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(
                    NOTIFICATION_ID,
                    notification,
                    ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
                )
            } else {
                startForeground(NOTIFICATION_ID, notification)
            }

            // 2. Create MediaStore record
            val (uri, descriptor) = createAudioMediaStoreEntry()
            outputUri = uri
            pfd = descriptor

            // 3. Initialize MediaRecorder (48kHz AAC in M4A container)
            mediaRecorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                MediaRecorder(this)
            } else {
                @Suppress("DEPRECATION")
                MediaRecorder()
            }.apply {
                setAudioSource(MediaRecorder.AudioSource.MIC)
                setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                setAudioSamplingRate(48_000)
                setAudioEncodingBitRate(128_000)
                setOutputFile(descriptor.fileDescriptor)
                prepare()
                start()
            }

            isPaused = false
            container?.updateVoiceStatus(RecordingStatus.RECORDING)
            container?.updateVoicePaused(false)

            startTimer()
            startAmplitudePolling()

        } catch (e: Exception) {
            Log.e(TAG, "Failed to start AudioRecordingService", e)
            container?.updateVoiceStatus(RecordingStatus.ERROR)
            stopRecording(isError = true)
        }
    }

    private fun pauseRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && !isPaused) {
            try {
                mediaRecorder?.pause()
                isPaused = true
                val app = application as? ScreenRecorderApp
                app?.container?.updateVoicePaused(true)
                updateNotification()
            } catch (e: Exception) {
                Log.e(TAG, "Error pausing audio recording", e)
            }
        }
    }

    private fun resumeRecording() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && isPaused) {
            try {
                mediaRecorder?.resume()
                isPaused = false
                val app = application as? ScreenRecorderApp
                app?.container?.updateVoicePaused(false)
                updateNotification()
            } catch (e: Exception) {
                Log.e(TAG, "Error resuming audio recording", e)
            }
        }
    }

    private fun createAudioMediaStoreEntry(): Pair<Uri, ParcelFileDescriptor> {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName = "REC_Voice_$timeStamp.m4a"

        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, fileName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mp4")
            put(MediaStore.Audio.Media.RELATIVE_PATH, "Recordings/VoiceRecordings")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }

        val uri = contentResolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values)
            ?: throw IllegalStateException("Failed to create MediaStore entry for voice recording")

        val fileDescriptor = contentResolver.openFileDescriptor(uri, "rw")
            ?: throw IllegalStateException("Failed to open descriptor for $uri")

        return Pair(uri, fileDescriptor)
    }

    private fun startTimer() {
        elapsedSeconds = 0
        timerJob?.cancel()
        timerJob = serviceScope.launch {
            while (isActive) {
                delay(1000L)
                if (!isPaused) {
                    elapsedSeconds++
                    (application as? ScreenRecorderApp)?.container?.updateVoiceDuration(elapsedSeconds)
                }
            }
        }
    }

    private fun startAmplitudePolling() {
        amplitudeJob?.cancel()
        amplitudeJob = serviceScope.launch {
            while (isActive) {
                delay(80L)
                if (!isPaused) {
                    val maxAmp = try {
                        mediaRecorder?.maxAmplitude ?: 0
                    } catch (e: Exception) {
                        0
                    }
                    val normalized = (maxAmp / 32768.0f).coerceIn(0.0f, 1.0f)
                    (application as? ScreenRecorderApp)?.container?.updateVoiceAmplitude(normalized)
                }
            }
        }
    }

    private fun stopRecording(isError: Boolean = false) {
        val app = application as? ScreenRecorderApp
        val container = app?.container

        timerJob?.cancel()
        timerJob = null
        amplitudeJob?.cancel()
        amplitudeJob = null

        try {
            mediaRecorder?.run {
                try {
                    stop()
                } catch (ignored: Exception) {}
                release()
            }
            mediaRecorder = null

            pfd?.close()
            pfd = null

            outputUri?.let { uri ->
                if (isError) {
                    contentResolver.delete(uri, null, null)
                } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    val values = ContentValues().apply {
                        put(MediaStore.Audio.Media.IS_PENDING, 0)
                    }
                    contentResolver.update(uri, values, null, null)
                }
            }

            container?.updateVoiceStatus(if (isError) RecordingStatus.ERROR else RecordingStatus.IDLE)
            container?.updateVoiceAmplitude(0.0f)
            container?.updateVoicePaused(false)
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping audio recording", e)
        } finally {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                stopForeground(STOP_FOREGROUND_REMOVE)
            } else {
                @Suppress("DEPRECATION")
                stopForeground(true)
            }
            stopSelf()
        }
    }

    private fun updateNotification() {
        val notificationManager = getSystemService(android.app.NotificationManager::class.java)
        notificationManager.notify(NOTIFICATION_ID, buildNotification(elapsedSeconds, isPaused))
    }

    private fun buildNotification(seconds: Int, paused: Boolean): Notification {
        val pauseResumeIntent = Intent(this, AudioRecordingService::class.java).apply {
            action = if (paused) ACTION_RESUME else ACTION_PAUSE
        }
        val pauseResumePendingIntent = PendingIntent.getService(
            this,
            1,
            pauseResumeIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AudioRecordingService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            2,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val mainActivityIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP
        }
        val contentPendingIntent = PendingIntent.getActivity(
            this,
            0,
            mainActivityIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val statusText = if (paused) "التسجيل متوقف مؤقتًا" else "جاري تسجيل الصوت النقي (48kHz AAC)"

        return NotificationCompat.Builder(this, ScreenRecorderApp.CHANNEL_AUDIO_RECORD)
            .setContentTitle("مسجل الصوت المستقل")
            .setContentText(statusText)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setOngoing(true)
            .setContentIntent(contentPendingIntent)
            .addAction(
                if (paused) android.R.drawable.ic_media_play else android.R.drawable.ic_media_pause,
                if (paused) "استئناف" else "إيقاف مؤقت",
                pauseResumePendingIntent
            )
            .addAction(android.R.drawable.ic_menu_save, "إيقاف وحفظ", stopPendingIntent)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    override fun onDestroy() {
        stopRecording()
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AudioRecordingService"
        private const val NOTIFICATION_ID = 2002

        const val ACTION_START = "com.example.screenrecorder.action.VOICE_START"
        const val ACTION_PAUSE = "com.example.screenrecorder.action.VOICE_PAUSE"
        const val ACTION_RESUME = "com.example.screenrecorder.action.VOICE_RESUME"
        const val ACTION_STOP = "com.example.screenrecorder.action.VOICE_STOP"
    }
}
