package com.example.screenrecorder.core.theme

import androidx.compose.ui.graphics.Color

val PrimaryRed = Color(0xFFE53935)
val PrimaryRedDark = Color(0xFFFF5252)
val SecondaryTeal = Color(0xFF00897B)
val SecondaryTealDark = Color(0xFF26A69A)

val BackgroundLight = Color(0xFFFAFAFA)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF0F0F0)
val OnSurfaceLight = Color(0xFF1E1E1E)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceVariantDark = Color(0xFF2A2A2A)
val OnSurfaceDark = Color(0xFFEEEEEE)

val AccentRecording = Color(0xFFFF1744)
val AccentSuccess = Color(0xFF4CAF50)
val CardBorder = Color(0xFFE0E0E0)
val CardBorderDark = Color(0xFF333333)
