package com.example.screenrecorder

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build

class ScreenRecorderApp : Application() {

    lateinit var container: AppContainer
        private set

    override fun onCreate() {
        super.onCreate()
        container = DefaultAppContainer(this)
        createNotificationChannels()
    }

    private fun createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val screenChannel = NotificationChannel(
                CHANNEL_SCREEN_RECORD,
                "تسجيل الشاشة",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات التحكم في تسجيل الشاشة المباشر"
                setShowBadge(false)
            }

            val audioChannel = NotificationChannel(
                CHANNEL_AUDIO_RECORD,
                "تسجيل الصوت",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "إشعارات التحكم في مسجل الصوت المباشر"
                setShowBadge(false)
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(screenChannel)
            manager.createNotificationChannel(audioChannel)
        }
    }

    companion object {
        const val CHANNEL_SCREEN_RECORD = "channel_screen_record"
        const val CHANNEL_AUDIO_RECORD = "channel_audio_record"
    }
}
