package com.example.screenrecorder.data.repository

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.MediaStore
import android.util.Log
import com.example.screenrecorder.data.model.RecordingItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

interface MediaRepository {
    val videosFlow: StateFlow<List<RecordingItem>>
    val audiosFlow: StateFlow<List<RecordingItem>>

    suspend fun refresh()
    suspend fun deleteItem(item: RecordingItem): Boolean
    fun createShareIntent(item: RecordingItem): Intent
}

class MediaRepositoryImpl(
    private val context: Context
) : MediaRepository {

    private val _videosFlow = MutableStateFlow<List<RecordingItem>>(emptyList())
    override val videosFlow: StateFlow<List<RecordingItem>> = _videosFlow.asStateFlow()

    private val _audiosFlow = MutableStateFlow<List<RecordingItem>>(emptyList())
    override val audiosFlow: StateFlow<List<RecordingItem>> = _audiosFlow.asStateFlow()

    override suspend fun refresh() = withContext(Dispatchers.IO) {
        _videosFlow.value = queryVideos()
        _audiosFlow.value = queryAudios()
    }

    private fun queryVideos(): List<RecordingItem> {
        val list = mutableListOf<RecordingItem>()
        val projection = arrayOf(
            MediaStore.Video.Media._ID,
            MediaStore.Video.Media.DISPLAY_NAME,
            MediaStore.Video.Media.DURATION,
            MediaStore.Video.Media.SIZE,
            MediaStore.Video.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Video.Media.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("REC_Screen_%")
        val sortOrder = "${MediaStore.Video.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Video.Media._ID)
                val nameCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DISPLAY_NAME)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Video.Media.DATE_ADDED)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val name = it.getString(nameCol) ?: "REC_Screen.mp4"
                    val durationMs = it.getLong(durationCol)
                    val sizeBytes = it.getLong(sizeCol)
                    val dateAddedSec = it.getLong(dateCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, id)

                    list.add(
                        RecordingItem(
                            id = id,
                            uri = uri,
                            name = name,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            dateAddedSec = dateAddedSec,
                            isVideo = true
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying video recordings from MediaStore", e)
        }
        return list
    }

    private fun queryAudios(): List<RecordingItem> {
        val list = mutableListOf<RecordingItem>()
        val projection = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.DISPLAY_NAME,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.SIZE,
            MediaStore.Audio.Media.DATE_ADDED
        )

        val selection = "${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?"
        val selectionArgs = arrayOf("REC_Voice_%")
        val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

        try {
            val cursor = context.contentResolver.query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                sortOrder
            )

            cursor?.use {
                val idCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val nameCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DISPLAY_NAME)
                val durationCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
                val sizeCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.SIZE)
                val dateCol = it.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)

                while (it.moveToNext()) {
                    val id = it.getLong(idCol)
                    val name = it.getString(nameCol) ?: "REC_Voice.m4a"
                    val durationMs = it.getLong(durationCol)
                    val sizeBytes = it.getLong(sizeCol)
                    val dateAddedSec = it.getLong(dateCol)
                    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id)

                    list.add(
                        RecordingItem(
                            id = id,
                            uri = uri,
                            name = name,
                            durationMs = durationMs,
                            sizeBytes = sizeBytes,
                            dateAddedSec = dateAddedSec,
                            isVideo = false
                        )
                    )
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error querying audio recordings from MediaStore", e)
        }
        return list
    }

    override suspend fun deleteItem(item: RecordingItem): Boolean = withContext(Dispatchers.IO) {
        try {
            val rowsDeleted = context.contentResolver.delete(item.uri, null, null)
            if (rowsDeleted > 0) {
                refresh()
                true
            } else {
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete recording item: ${item.uri}", e)
            false
        }
    }

    override fun createShareIntent(item: RecordingItem): Intent {
        return Intent(Intent.ACTION_SEND).apply {
            type = if (item.isVideo) "video/mp4" else "audio/mp4"
            putExtra(Intent.EXTRA_STREAM, item.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
    }

    companion object {
        private const val TAG = "MediaRepository"
    }
}
