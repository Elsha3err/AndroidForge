# Standard Android Proguard rules for ScreenRecorder
-keepattributes *Annotation*
-keepclassmembers class * {
    @androidx.annotation.Keep *;
}
